package com.yadavar.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import androidx.core.app.NotificationCompat
import org.json.JSONArray
import org.json.JSONObject

object Alarms {
    private const val CH = "alarm_channel"
    private const val FLAGS = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

    private fun pi(c: Context, code: Int, o: JSONObject?): PendingIntent {
        val i = Intent(c, AlarmReceiver::class.java)
        if (o != null) {
            i.putExtra("title", o.optString("title"))
            i.putExtra("text", o.optString("text"))
        }
        return PendingIntent.getBroadcast(c, code, i, FLAGS)
    }

    private fun code(o: JSONObject): Int = (o.optLong("id") % 1000000000L).toInt()

    fun schedule(c: Context, json: String) {
        val sp = c.getSharedPreferences("alarms", Context.MODE_PRIVATE)
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val old = JSONArray(sp.getString("json", "[]"))
        for (k in 0 until old.length()) am.cancel(pi(c, code(old.getJSONObject(k)), null))
        val now = System.currentTimeMillis()
        val arr = JSONArray(json)
        val show = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), FLAGS)
        for (k in 0 until arr.length()) {
            val o = arr.getJSONObject(k)
            val at = o.optLong("at")
            if (at > now) am.setAlarmClock(AlarmManager.AlarmClockInfo(at, show), pi(c, code(o), o))
        }
        sp.edit().putString("json", json).apply()
    }

    fun ring(c: Context, title: String, text: String) {
        val nm = c.getSystemService(NotificationManager::class.java)
        val ch = NotificationChannel(CH, "هشدارها", NotificationManager.IMPORTANCE_HIGH)
        ch.setSound(
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        )
        ch.enableVibration(true)
        ch.vibrationPattern = longArrayOf(0, 500, 300, 500)
        nm.createNotificationChannel(ch)
        val open = PendingIntent.getActivity(
            c, 1,
            Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            FLAGS
        )
        val n = NotificationCompat.Builder(c, CH)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setFullScreenIntent(open, true)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        n.flags = n.flags or Notification.FLAG_INSISTENT
        nm.notify(title.hashCode(), n)
    }

    fun stop(c: Context) {
        c.getSystemService(NotificationManager::class.java).cancelAll()
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Alarms.ring(c, i.getStringExtra("title") ?: "یادآور", i.getStringExtra("text") ?: "")
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val json = c.getSharedPreferences("alarms", Context.MODE_PRIVATE).getString("json", "[]") ?: "[]"
        Alarms.schedule(c, json)
    }
}
